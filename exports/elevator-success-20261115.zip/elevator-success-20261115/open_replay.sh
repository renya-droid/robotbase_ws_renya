#!/usr/bin/env bash
set -euo pipefail
REPLAY_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec /usr/bin/foxglove-studio "$REPLAY_ROOT/data/data_0.mcap"
